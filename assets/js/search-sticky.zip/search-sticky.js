/* =====================================================
   SEARCH STICKY - Закрепленный поиск с Liquid Glass эффектом
   ===================================================== */

(function() {
  'use strict';

  const searchContainer = document.querySelector('.product__search-container');
  const searchWrapper = document.querySelector('.product__search-wrapper');
  
  if (!searchContainer || !searchWrapper) return;

  let lastScrollTop = 0;
  let ticking = false;
  let initialOffsetTop = 0;
  let initialOffsetLeft = 0;
  let initialWidth = 0;
  let isFixed = false;

  /**
   * Получает начальную позицию элемента
   */
  function getInitialPosition() {
    const rect = searchContainer.getBoundingClientRect();
    initialOffsetTop = rect.top + window.pageYOffset;
    initialOffsetLeft = rect.left + window.pageXOffset;
    initialWidth = rect.width;
  }

  /**
   * Обновляет стили при скролле
   */
  function updateOnScroll() {
    const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
    
    // Если еще не получили начальную позицию, получаем её
    if (initialOffsetTop === 0) {
      getInitialPosition();
      return;
    }
    
    // Переключаем на fixed при скролле вниз
    if (scrollTop > initialOffsetTop - 20) {
      if (!isFixed) {
        isFixed = true;
        searchContainer.style.position = 'fixed';
        searchContainer.style.top = '0';
        searchContainer.style.left = '50%';
        searchContainer.style.transform = 'translateX(-50%)';
        searchContainer.style.width = '1440px';
        searchContainer.style.maxWidth = '1440px';
        searchContainer.style.margin = '0';
        searchContainer.style.zIndex = '1000';
        searchContainer.classList.add('is-scrolled');
      }
      
      // Обновляем ширину при изменении размера окна (для адаптивности)
      if (isFixed) {
        const windowWidth = window.innerWidth;
        const containerWidth = Math.min(1440, windowWidth - 40);
        searchContainer.style.width = `${containerWidth}px`;
      }
    } else {
      if (isFixed) {
        isFixed = false;
        searchContainer.style.position = 'sticky';
        searchContainer.style.top = '0';
        searchContainer.style.left = '';
        searchContainer.style.transform = '';
        searchContainer.style.width = '';
        searchContainer.style.maxWidth = '';
        searchContainer.style.margin = '';
        searchContainer.style.zIndex = '';
        searchContainer.classList.remove('is-scrolled');
      }
    }

    // Плавное изменение blur в зависимости от скролла
    const scrollProgress = Math.min((scrollTop - initialOffsetTop + 20) / 200, 1); // От 0 до 1
    
    // Применяем динамические стили для более интенсивного эффекта при скролле
    if (scrollProgress > 0 && isFixed) {
      const blurValue = 30 + (scrollProgress * 10); // От 30px до 40px
      searchContainer.style.setProperty('--scroll-blur', `${blurValue}px`);
      searchContainer.style.backdropFilter = `blur(${blurValue}px) saturate(220%)`;
      searchContainer.style.webkitBackdropFilter = `blur(${blurValue}px) saturate(220%)`;
    } else {
      searchContainer.style.removeProperty('--scroll-blur');
      if (!isFixed) {
        searchContainer.style.backdropFilter = '';
        searchContainer.style.webkitBackdropFilter = '';
      }
    }

    lastScrollTop = scrollTop <= 0 ? 0 : scrollTop;
    ticking = false;
  }

  /**
   * Оптимизированный обработчик скролла
   */
  function onScroll() {
    if (!ticking) {
      window.requestAnimationFrame(updateOnScroll);
      ticking = true;
    }
  }

  // Получаем начальную позицию при загрузке
  window.addEventListener('load', () => {
    setTimeout(() => {
      getInitialPosition();
    }, 100);
  });

  // Слушаем событие скролла
  window.addEventListener('scroll', onScroll, { passive: true });

  // Инициализация при загрузке
  setTimeout(() => {
    getInitialPosition();
    updateOnScroll();
  }, 200);

  // Обновляем при изменении размера окна
  window.addEventListener('resize', () => {
    if (!isFixed) {
      getInitialPosition();
    } else {
      // Если fixed, обновляем ширину для центрирования (максимум 1440px)
      const windowWidth = window.innerWidth;
      const containerWidth = Math.min(1440, windowWidth - 40);
      searchContainer.style.width = `${containerWidth}px`;
    }
    updateOnScroll();
  }, { passive: true });
})();

